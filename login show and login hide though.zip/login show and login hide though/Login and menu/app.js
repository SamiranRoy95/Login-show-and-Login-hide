
// This Seclector 
var login=document.getElementById("login");




// This is login form display function 
login.addEventListener("click",function(){

var loginDiv=document.getElementById("loginDiv");
loginDiv.style.display="block";


});

var modal=document.getElementById("loginDiv");

window.onclick=function(event){
    if(event.target==modal)
    {
        modal.style.display="none";
    }
}
